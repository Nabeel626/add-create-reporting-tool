﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Time_Reporting_Tool
{
    public partial class Produce_Report_Main_Menu : Form
    {
        public Produce_Report_Main_Menu()
        {
            InitializeComponent();
        }

        private void return_menu1_Click(object sender, EventArgs e)
        {
            this.Hide();
            
            Form1 back = new Form1();
            back.ShowDialog();
            back.Activate();

        }

        private void weekly_report_Click(object sender, EventArgs e)
        {
            this.Hide();

            Weekly_Report_page weekly = new Weekly_Report_page();
            weekly.ShowDialog();
            weekly.Activate();

        }

        private void four_week_report_Click(object sender, EventArgs e)
        {

        }
    }
}
