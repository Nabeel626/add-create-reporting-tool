﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Time_Reporting_Tool
{
    public partial class Add_Contact_page : Form
    {
        public Add_Contact_page()
        {
            InitializeComponent();
        }

        /****************************************************These are the assets************************************************/
        TextBox Fname = new TextBox();
        TextBox Lname = new TextBox();
        TextBox Address1 = new TextBox();
        TextBox Address2 = new TextBox();
        TextBox Phone = new TextBox();
        TextBox Email = new TextBox();

        DateTimePicker dob = new DateTimePicker();

        Label label_fname = new Label();
        Label label_lname = new Label();
        Label label_dob = new Label();
        Label label_address1 = new Label();
        Label label_address2 = new Label();
        Label label_phone = new Label();
        Label label_email = new Label();

        private void return_menu2_Click(object sender, EventArgs e)
        {
            this.Hide();

            Contact_Main_Menu back = new Contact_Main_Menu();
            back.Activate();
            back.ShowDialog();
        }

        private void Add_Contact_page_Load(object sender, EventArgs e)
        {

        }

        private void save_contact_Click(object sender, EventArgs e)
        {

            int i = 0;

            /***********************************This is for the textboxes and date to appear****************************************/
            this.Controls.Add(Fname);
            Fname.Top = 173;
            Fname.Left = 190;
            Fname.Size = new System.Drawing.Size(180, 25);

            this.Controls.Add(Lname);
            Lname.Top = 170;
            Lname.Left = 570;
            Lname.Size = new System.Drawing.Size(180, 25);

            this.Controls.Add(dob);
            dob.Top = 243;
            dob.Left = 190;
            dob.Value = DateTimePicker.MinimumDateTime;
            dob.Size = new System.Drawing.Size(180, 25);

            this.Controls.Add(Address1);
            Address1.Top = 313;
            Address1.Left = 190;
            Address1.Size = new System.Drawing.Size(180, 25);

            this.Controls.Add(Address2);
            Address2.Top = 313;
            Address2.Left = 570;
            Address2.Size = new System.Drawing.Size(180, 25);

            this.Controls.Add(Phone);
            Phone.Top = 383;
            Phone.Left = 190;
            Phone.Size = new System.Drawing.Size(180, 25);

            this.Controls.Add(Email);
            Email.Top = 453;
            Email.Left = 190;
            Email.Size = new System.Drawing.Size(180, 100);

            /*******************************************This is for the labels to appear********************************************/
            System.Drawing.Point label1 = new System.Drawing.Point(89, 170  + i * 10);
            label_fname.Location = label1;
            label_fname.Text = "*First Name: ";
            label_fname.Font = new Font("Century Gothic", 11);
            this.Controls.Add(label_fname);

            System.Drawing.Point label2 = new System.Drawing.Point(470, 170 + i * 10);
            label_lname.Location = label2;
            label_lname.Text = "*Last Name: ";
            label_lname.Font = new Font("Century Gothic", 11);
            this.Controls.Add(label_lname);

            System.Drawing.Point label3 = new System.Drawing.Point(79, 240 + i * 10);
            label_dob.Location = label3;
            label_dob.Size = new System.Drawing.Size(200, 20);
            label_dob.Text = "Date of Birth: ";
            label_dob.Font = new Font("Century Gothic", 11);
            this.Controls.Add(label_dob);

            System.Drawing.Point label4 = new System.Drawing.Point(60, 310 + i * 10);
            label_address1.Location = label4;
            label_address1.Size = new System.Drawing.Size(200, 20);
            label_address1.Text = "*Address Line 1: ";
            label_address1.Font = new Font("Century Gothic", 11);
            this.Controls.Add(label_address1);

            System.Drawing.Point label5 = new System.Drawing.Point(441, 311 + i * 10);
            label_address2.Location = label5;
            label_address2.Size = new System.Drawing.Size(200, 20);
            label_address2.Text = "*Address Line 2: ";
            label_address2.Font = new Font("Century Gothic", 11);
            this.Controls.Add(label_address2);

            System.Drawing.Point label6 = new System.Drawing.Point(53, 380 + i * 10);
            label_phone.Location = label6;
            label_phone.Size = new System.Drawing.Size(200, 20);
            label_phone.Text = "*Phone Number: ";
            label_phone.Font = new Font("Century Gothic", 11);
            this.Controls.Add(label_phone);

            System.Drawing.Point label17 = new System.Drawing.Point(63, 450 + i * 10);
            label_email.Location = label17;
            label_email.Size = new System.Drawing.Size(200, 20);
            label_email.Text = "*Email Address: ";
            label_email.Font = new Font("Century Gothic", 11);
            this.Controls.Add(label_email);

        }

        private void save_contact_Click_1(object sender, EventArgs e)
        {

            if (Fname.Text.Equals("") || Lname.Text.Equals("") || Address1.Text.Equals("") || Address2.Text.Equals("") || Email.Text.Equals("") || Phone.Text.Equals("")) 
            {
                MessageBox.Show("Please Enter Your Details!");
            }
            else
            {
                save_data();

                Add_Contact_page refresh = new Add_Contact_page();
                refresh.Activate();
                refresh.ShowDialog();
                Hide();
            }
        }

        private void save_data()
        {
            ThreadStart threading = new ThreadStart(threading_Contact); //This starts the beginning of the thread, calls the method
            Thread start_thread = new Thread(threading); //This creates the thread, calls the the thread start
            start_thread.Start(); //This officially starts

        }

        private void threading_Contact()
        {
            OleDbCommand command;
            OleDbConnection dbConnection = new OleDbConnection();

            dbConnection.ConnectionString = ConfigurationManager.ConnectionStrings["connection_add"].ToString();
            dbConnection.Open();

            command = new OleDbCommand("INSERT INTO [Add] (FirstName, LastName, Dob, AddressLine1, AddressLine2, Phonenum, Email) " +
                "VALUES (@fname, @lname, @dob, @address1, @address2, @phone, @email)", dbConnection);


            command.Parameters.AddWithValue("@fname", Fname.Text);
            command.Parameters.AddWithValue("@lname", Lname.Text);
            command.Parameters.AddWithValue("@dob", dob.Text);
            command.Parameters.AddWithValue("@address1", Address1.Text);
            command.Parameters.AddWithValue("@address2", Address2.Text);
            command.Parameters.AddWithValue("@phone", Phone.Text);
            command.Parameters.AddWithValue("@email", Email.Text);
            command.Connection = dbConnection;

            int i = command.ExecuteNonQuery();

            if (i > 0)
            {
                MessageBox.Show("Your Details have been Saved!");
            }

            dbConnection.Close();

        }

    }
}
