﻿namespace Time_Reporting_Tool
{
    partial class Event_Main_Menucs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.edit_event = new System.Windows.Forms.Button();
            this.return_menu1 = new System.Windows.Forms.Button();
            this.view_event = new System.Windows.Forms.Button();
            this.add_event = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Agency FB", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(13, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(341, 73);
            this.label1.TabIndex = 0;
            this.label1.Text = "Event Main Menu";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // edit_event
            // 
            this.edit_event.Cursor = System.Windows.Forms.Cursors.Hand;
            this.edit_event.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.edit_event.Location = new System.Drawing.Point(643, 190);
            this.edit_event.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.edit_event.Name = "edit_event";
            this.edit_event.Size = new System.Drawing.Size(221, 78);
            this.edit_event.TabIndex = 12;
            this.edit_event.Text = "Edit Event";
            this.edit_event.UseVisualStyleBackColor = true;
            this.edit_event.Click += new System.EventHandler(this.Edit_contact_Click);
            // 
            // return_menu1
            // 
            this.return_menu1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.return_menu1.BackColor = System.Drawing.Color.Silver;
            this.return_menu1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.return_menu1.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.return_menu1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.return_menu1.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.return_menu1.Location = new System.Drawing.Point(783, 502);
            this.return_menu1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.return_menu1.Name = "return_menu1";
            this.return_menu1.Size = new System.Drawing.Size(269, 38);
            this.return_menu1.TabIndex = 11;
            this.return_menu1.Text = "Return To Menu";
            this.return_menu1.UseVisualStyleBackColor = false;
            this.return_menu1.Click += new System.EventHandler(this.Return_menu1_Click);
            // 
            // view_event
            // 
            this.view_event.Cursor = System.Windows.Forms.Cursors.Hand;
            this.view_event.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.view_event.Location = new System.Drawing.Point(419, 354);
            this.view_event.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.view_event.Name = "view_event";
            this.view_event.Size = new System.Drawing.Size(242, 78);
            this.view_event.TabIndex = 9;
            this.view_event.Text = "View/ Remove Event";
            this.view_event.UseVisualStyleBackColor = true;
            this.view_event.Click += new System.EventHandler(this.View_contact_Click);
            // 
            // add_event
            // 
            this.add_event.Cursor = System.Windows.Forms.Cursors.Hand;
            this.add_event.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add_event.Location = new System.Drawing.Point(204, 190);
            this.add_event.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.add_event.Name = "add_event";
            this.add_event.Size = new System.Drawing.Size(221, 78);
            this.add_event.TabIndex = 8;
            this.add_event.Text = "Add Event";
            this.add_event.UseVisualStyleBackColor = true;
            this.add_event.Click += new System.EventHandler(this.Add_contact_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(1, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1068, 123);
            this.panel1.TabIndex = 7;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // Event_Main_Menucs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.edit_event);
            this.Controls.Add(this.return_menu1);
            this.Controls.Add(this.view_event);
            this.Controls.Add(this.add_event);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Event_Main_Menucs";
            this.Text = "Event_Main_Menu";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button edit_event;
        private System.Windows.Forms.Button return_menu1;
        private System.Windows.Forms.Button view_event;
        private System.Windows.Forms.Button add_event;
        private System.Windows.Forms.Panel panel1;
    }
}