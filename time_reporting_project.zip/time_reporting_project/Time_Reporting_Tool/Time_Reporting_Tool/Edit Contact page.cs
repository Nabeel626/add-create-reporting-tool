﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Time_Reporting_Tool
{
    public partial class Edit_Contact_page : Form
    {
        public Edit_Contact_page()
        {
            InitializeComponent();
        }

        TextBox text_id = new TextBox();
        TextBox text_firstn = new TextBox();
        TextBox text_lastn = new TextBox();
        TextBox address1 = new TextBox();
        TextBox address2 = new TextBox();
        TextBox phone = new TextBox();
        TextBox email = new TextBox();

        DateTimePicker text_date = new DateTimePicker();

        Label label_id = new Label();
        Label label_fname = new Label();
        Label label_lname = new Label();
        Label label_dob = new Label();
        Label label_address1 = new Label();
        Label label_address2 = new Label();
        Label label_phone = new Label();
        Label label_email = new Label();

        private void Return_menu1_Click(object sender, EventArgs e)
        {
            this.Hide();

            Contact_Main_Menu back = new Contact_Main_Menu();
            back.Activate();
            back.ShowDialog();
        }

        private void Edit_Contact_page_Load(object sender, EventArgs e)
        {
            OleDbCommand command1;
            OleDbConnection dbConnection = new OleDbConnection();

            dbConnection.ConnectionString = ConfigurationManager.ConnectionStrings["connection_add"].ToString();
            dbConnection.Open();
            command1 = new OleDbCommand("SELECT * FROM [Add]", dbConnection);
            command1.Connection = dbConnection;

            OleDbDataReader reader = command1.ExecuteReader();
            while (reader.Read())
            {
                comboBox1.Items.Add(reader["FirstName"].ToString());
            }

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            OleDbCommand command;
            OleDbConnection dbConnection = new OleDbConnection();

            dbConnection.ConnectionString = ConfigurationManager.ConnectionStrings["connection_add"].ToString();
            dbConnection.Open();
            command = new OleDbCommand("SELECT * FROM [Add] WHERE FirstName='" + comboBox1.Text + "'", dbConnection);

            command.Connection = dbConnection;
            OleDbDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                text_id.Text = reader["ID"].ToString();
                text_firstn.Text = reader["FirstName"].ToString();
                text_lastn.Text = reader["LastName"].ToString();
                text_date.Text = reader["Dob"].ToString();
                address1.Text = reader["AddressLine1"].ToString();
                address2.Text = reader["AddressLine2"].ToString();
                phone.Text = reader["Phonenum"].ToString();
                email.Text = reader["Email"].ToString();

                assets();
            }
        }

        private void assets()
        {
            int i = 0;

            /***************************************This is for the textboxes to appear*********************************************/
            this.Controls.Add(text_id);
            text_id.Top = 173;
            text_id.Left = 190;
            text_id.Enabled = false;
            text_id.Size = new System.Drawing.Size(180, 25);

            this.Controls.Add(text_firstn);
            text_firstn.Top = 243;
            text_firstn.Left = 190;
            text_firstn.Size = new System.Drawing.Size(180, 25);

            this.Controls.Add(text_lastn);
            text_lastn.Top = 243;
            text_lastn.Left = 570;
            text_lastn.Size = new System.Drawing.Size(180, 25);

            this.Controls.Add(text_date);
            text_date.Top = 313;
            text_date.Left = 190;
            text_date.Size = new System.Drawing.Size(180, 25);

            this.Controls.Add(address1);
            address1.Top = 383;
            address1.Left = 190;
            address1.Size = new System.Drawing.Size(180, 25);

            this.Controls.Add(address2);
            address2.Top = 383;
            address2.Left = 570;
            address2.Size = new System.Drawing.Size(180, 25);

            this.Controls.Add(phone);
            phone.Top = 453;
            phone.Left = 190;
            phone.Size = new System.Drawing.Size(180, 100);

            this.Controls.Add(email);
            email.Top = 533;
            email.Left = 190;
            email.Size = new System.Drawing.Size(180, 100);

            /**********************************This is for the labels and buttons to appear*****************************************/
            System.Drawing.Point label11 = new System.Drawing.Point(150, 170 + i * 10);
            label_id.Location = label11;
            label_id.Text = "ID: ";
            label_id.Font = new Font("Century Gothic", 11);
            this.Controls.Add(label_id);

            System.Drawing.Point label1 = new System.Drawing.Point(89, 240 + i * 10);
            label_fname.Location = label1;
            label_fname.Text = "First Name: ";
            label_fname.Font = new Font("Century Gothic", 11);
            this.Controls.Add(label_fname);

            System.Drawing.Point label2 = new System.Drawing.Point(470, 240 + i * 10);
            label_lname.Location = label2;
            label_lname.Text = "Last Name: ";
            label_lname.Font = new Font("Century Gothic", 11);
            this.Controls.Add(label_lname);

            System.Drawing.Point label3 = new System.Drawing.Point(72, 311 + i * 10);
            label_dob.Location = label3;
            label_dob.Size = new System.Drawing.Size(200, 20);
            label_dob.Text = "Date of Birth: ";
            label_dob.Font = new Font("Century Gothic", 11);
            this.Controls.Add(label_dob);

            System.Drawing.Point label4 = new System.Drawing.Point(60, 380 + i * 10);
            label_address1.Location = label4;
            label_address1.Size = new System.Drawing.Size(200, 20);
            label_address1.Text = "Address Line 1: ";
            label_address1.Font = new Font("Century Gothic", 11);
            this.Controls.Add(label_address1);

            System.Drawing.Point label5 = new System.Drawing.Point(441, 380 + i * 10);
            label_address2.Location = label5;
            label_address2.Size = new System.Drawing.Size(200, 20);
            label_address2.Text = "Address Line 2: ";
            label_address2.Font = new Font("Century Gothic", 11);
            this.Controls.Add(label_address2);

            System.Drawing.Point label6 = new System.Drawing.Point(53, 450 + i * 10);
            label_phone.Location = label6;
            label_phone.Size = new System.Drawing.Size(200, 20);
            label_phone.Text = "Phone Number: ";
            label_phone.Font = new Font("Century Gothic", 11);
            this.Controls.Add(label_phone);

            System.Drawing.Point label17 = new System.Drawing.Point(63, 530 + i * 10);
            label_email.Location = label17;
            label_email.Size = new System.Drawing.Size(200, 20);
            label_email.Text = "Email Address: ";
            label_email.Font = new Font("Century Gothic", 11);
            this.Controls.Add(label_email);
        }

        private void change_contact_Click(object sender, EventArgs e)
        {

            ThreadStart threading = new ThreadStart(Threading_statement); //This starts the beginning of the thread, calls the method
            Thread start_thread = new Thread(threading); //This creates the thread, calls the the thread start
            start_thread.Start(); //This officially starts

        }

        private void Threading_statement()
        {
            OleDbCommand command;
            OleDbConnection dbConnection = new OleDbConnection();

            dbConnection.ConnectionString = ConfigurationManager.ConnectionStrings["connection_add"].ToString();
            dbConnection.Open();

            command = new OleDbCommand("UPDATE [Add] SET FirstName='" + text_firstn.Text + "' , LastName='" + text_lastn.Text +
                "', Dob='" + text_date.Text + "', AddressLine1='" + address1.Text + "' , AddressLine2='" + address2.Text +
                "', Phonenum ='" + phone.Text + "' , Email='" + email.Text + "' WHERE ID=" + text_id.Text + "", dbConnection);
            command.Connection = dbConnection;

            int i = command.ExecuteNonQuery();

            if (i > 0)
            {
                MessageBox.Show("Your Details have been Changed!");
            }
            else
            {
                MessageBox.Show("Your Detials have NOT been Chnaged!");
            }

            dbConnection.Close();

        }
    }
}
