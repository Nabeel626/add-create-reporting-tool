﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Time_Reporting_Tool
{
    public partial class Edit_Event_page : Form
    {

        ComboBox input = new ComboBox();
        ComboBox option_type = new ComboBox();

        Label ID = new Label();
        Label Event_Name = new Label();
        Label Date_label = new Label();
        Label Time_label = new Label();
        Label Duration_label = new Label();
        Label Location_label = new Label();
        Label EventDetails_label = new Label();

        TextBox textBox_ID = new TextBox();
        TextBox textBox_eventName = new TextBox();
        TextBox textBox_Time = new TextBox();
        TextBox textBox_duration = new TextBox();
        TextBox textBox_location = new TextBox();
        TextBox textBox_eventDetails = new TextBox();

        Button update_event = new Button();
        Button return_EventMenu = new Button();

        GroupBox box = new GroupBox();
        RadioButton option1 = new RadioButton();
        RadioButton option2 = new RadioButton();

        GroupBox box2 = new GroupBox();

        DateTimePicker date_pick = new DateTimePicker();

        public Edit_Event_page()
        {
            InitializeComponent();
            input.SelectedIndexChanged += new EventHandler(this.combo_IndexChanged);
            update_event.Click += new EventHandler(this.update_Event_Click);
            return_EventMenu.Click += new EventHandler(this.return_menu1_Click);

            this.Controls.Add(input);
            input.Top = 120;
            input.Left = 350;
            input.Size = new System.Drawing.Size(150, 25);

            this.Controls.Add(return_EventMenu);
            return_EventMenu.Top = 520;
            return_EventMenu.Left = 585;
            return_EventMenu.Text = "Return to Event Menu";
            return_EventMenu.Font = new Font("Century Gothic", 14, FontStyle.Bold);
            return_EventMenu.FlatStyle = FlatStyle.Flat;
            return_EventMenu.FlatAppearance.BorderColor = Color.Silver;
            return_EventMenu.BringToFront();
            return_EventMenu.Cursor = Cursors.Hand;
            return_EventMenu.Size = new System.Drawing.Size(230, 38);
        }

        private void return_menu1_Click(object sender, EventArgs e)
        {
            this.Hide();

            Event_Main_Menucs back2 = new Event_Main_Menucs();
            back2.Activate();
            back2.ShowDialog();
        }

        private void assets()
        {
            int i = 0;

            /*******************************This is for the textboxes and groupboxes to appear***********************************/
            this.Controls.Add(box);
            box.Controls.Add(option1);
            box.Controls.Add(option2);
            box.Top = 240;
            box.Left = 60;
            box.Text = "Event Type: ";
            box.Font = new Font("Century Gothic", 11);

            this.Controls.Add(box2);
            box2.Controls.Add(option_type);
            box2.Top = 380;
            box2.Left = 60;
            box2.Text = "Event Option: ";
            box2.Font = new Font("Century Gothic", 11);

            this.Controls.Add(option1);
            option1.Top = 270;
            option1.Left = 90;
            option1.Text = "Task";
            option1.Font = new Font("Century Gothic", 10);
            option1.BringToFront();
            option1.Size = new System.Drawing.Size(130, 25);

            this.Controls.Add(option2);
            option2.Top = 300;
            option2.Left = 90;
            option2.Text = "Appointment";
            option2.Font = new Font("Century Gothic", 10);
            option2.BringToFront();
            option2.Size = new System.Drawing.Size(130, 25);

            this.Controls.Add(option_type);
            option_type.Top = 425;
            option_type.Left = 90;
            option_type.BringToFront();
            option_type.Size = new System.Drawing.Size(130, 25);

            this.Controls.Add(textBox_ID);
            textBox_ID.Top = 180;
            textBox_ID.Left = 130;
            textBox_ID.Enabled = false;
            textBox_ID.Size = new System.Drawing.Size(120, 25);

            this.Controls.Add(date_pick);
            date_pick.Top = 180;
            date_pick.Left = 370;
            date_pick.Size = new System.Drawing.Size(170, 25);

            this.Controls.Add(textBox_Time);
            textBox_Time.Top = 260;
            textBox_Time.Left = 370;
            textBox_Time.Size = new System.Drawing.Size(170, 25);

            this.Controls.Add(textBox_duration);
            textBox_duration.Top = 340;
            textBox_duration.Left = 370;
            textBox_duration.Size = new System.Drawing.Size(170, 25);

            this.Controls.Add(textBox_location);
            textBox_location.Top = 420;
            textBox_location.Multiline = true;
            textBox_location.Left = 370;
            textBox_location.Size = new System.Drawing.Size(170, 40);

            this.Controls.Add(textBox_eventName);
            textBox_eventName.Top = 210;
            textBox_eventName.Left = 580;
            textBox_eventName.Size = new System.Drawing.Size(200, 25);

            this.Controls.Add(textBox_eventDetails);
            textBox_eventDetails.Top = 290;
            textBox_eventDetails.Multiline = true;
            textBox_eventDetails.Left = 580;
            textBox_eventDetails.Size = new System.Drawing.Size(200, 170);

            /************************************This is for the labels and buttons to appear*************************************/
            System.Drawing.Point label1 = new System.Drawing.Point(80, 180 + i * 10);
            ID.Location = label1;
            ID.Text = "ID: ";
            ID.Font = new Font("Century Gothic", 10);
            this.Controls.Add(ID);

            System.Drawing.Point label2 = new System.Drawing.Point(310, 180 + i * 10);
            Date_label.Location = label2;
            Date_label.Text = "Date: ";
            Date_label.Font = new Font("Century Gothic", 10);
            this.Controls.Add(Date_label);

            System.Drawing.Point label3 = new System.Drawing.Point(315, 260 + i * 10);
            Time_label.Location = label3;
            Time_label.Text = "Time: ";
            Time_label.Font = new Font("Century Gothic", 10);
            this.Controls.Add(Time_label);

            System.Drawing.Point label4 = new System.Drawing.Point(287, 340 + i * 10);
            Duration_label.Location = label4;
            Duration_label.Text = "Duration: ";
            Duration_label.Font = new Font("Century Gothic", 10);
            this.Controls.Add(Duration_label);

            System.Drawing.Point label5 = new System.Drawing.Point(287, 420 + i * 10);
            Location_label.Location = label5;
            Location_label.Text = "Location: ";
            Location_label.Font = new Font("Century Gothic", 10);
            this.Controls.Add(Location_label);

            System.Drawing.Point label6 = new System.Drawing.Point(580, 257 + i * 10);
            EventDetails_label.Location = label6;
            EventDetails_label.Text = "Event Details: ";
            EventDetails_label.Size = new System.Drawing.Size(180, 150);
            EventDetails_label.Font = new Font("Century Gothic", 10);
            this.Controls.Add(EventDetails_label);

            System.Drawing.Point label7 = new System.Drawing.Point(580, 178 + i * 10);
            Event_Name.Location = label7;
            Event_Name.Text = "Event Name: ";
            Event_Name.Size = new System.Drawing.Size(180, 150);
            Event_Name.Font = new Font("Century Gothic", 10);
            this.Controls.Add(Event_Name);

            this.Controls.Add(update_event);
            update_event.Top = 521;
            update_event.Left = 15;
            update_event.Text = "Update Event";
            update_event.Font = new Font("Century Gothic", 14, FontStyle.Bold);
            update_event.FlatStyle = FlatStyle.Flat;
            update_event.FlatAppearance.BorderColor = Color.Silver;
            update_event.BringToFront();
            update_event.Cursor = Cursors.Hand;
            update_event.Size = new System.Drawing.Size(180, 38);
        }

        private void Edit_Event_page_Load(object sender, EventArgs e)
        {
            OleDbCommand command1;
            OleDbConnection dbConnection = new OleDbConnection();

            dbConnection.ConnectionString = ConfigurationManager.ConnectionStrings["connection_add"].ToString();
            dbConnection.Open();
            command1 = new OleDbCommand("SELECT * FROM [Event]", dbConnection);
            command1.Connection = dbConnection;

            OleDbDataReader reader = command1.ExecuteReader();
            while (reader.Read())
            {
                input.Items.Add(reader["EventName"].ToString());
            }
        }

        private void combo_IndexChanged(object sender, EventArgs e)
        {
            OleDbCommand command;
            OleDbConnection dbConnection = new OleDbConnection();

            dbConnection.ConnectionString = ConfigurationManager.ConnectionStrings["connection_add"].ToString();
            dbConnection.Open();
            command = new OleDbCommand("SELECT * FROM [Event] WHERE EventName='" + input.Text + "' ", dbConnection);

            command.Connection = dbConnection;
            OleDbDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                textBox_ID.Text = reader["ID"].ToString();
                textBox_eventName.Text = reader["EventName"].ToString();

                if (reader["Type"].ToString() == "Task")
                {
                    option1.Checked = true;
                } 
                else
                {
                    option2.Checked = true;
                }

                if (reader["OptionType"].ToString() == "One-Off")
                {
                    option_type.Items.Clear();
                    option_type.Text = "One-Off";
                    option_type.Items.Add("One-Off");
                    option_type.Items.Add("Recurring");
                } 
                else
                {
                    option_type.Items.Clear();
                    option_type.Text = "Recurring";
                    option_type.Items.Add("Recurring");
                    option_type.Items.Add("One-Off");
                }
                
                date_pick.Text = reader["DateEvent"].ToString();
                textBox_Time.Text = reader["TimeEvent"].ToString();
                textBox_duration.Text = reader["Duration"].ToString();
                textBox_location.Text = reader["Location"].ToString();
                textBox_eventDetails.Text = reader["EventDetails"].ToString();

                assets();
            }
        }

        private void update_Event_Click(object sender, EventArgs e)
        {
            String radio_text = "";

            if (option1.Checked == true)
            {
                radio_text =  option1.Text;
            } else
            {
                radio_text = option2.Text;
            }
            
            OleDbCommand command;
            OleDbConnection dbConnection = new OleDbConnection();

            dbConnection.ConnectionString = ConfigurationManager.ConnectionStrings["connection_add"].ToString();
            dbConnection.Open();

            command = new OleDbCommand("UPDATE [Event] SET EventName='" + textBox_eventName.Text +  "' , Type='" + radio_text + "' , OptionType='" + option_type.Text +
                "', DateEvent='" + date_pick.Text + "', TimeEvent='" + textBox_Time.Text + "' , Location='" + textBox_location.Text +
                "', EventDetails ='" + textBox_eventDetails.Text + "' , Duration='" + textBox_duration.Text + "' WHERE ID=" + textBox_ID.Text + "", dbConnection);
            command.Connection = dbConnection;

            int i = command.ExecuteNonQuery();

            if (i > 0)
            {
                MessageBox.Show("Your Event have been Changed!");
            }
            else
            {
                MessageBox.Show("Your Event have NOT been Chnaged!");
            }

            dbConnection.Close();

            this.Hide();
            Edit_Event_page refresh = new Edit_Event_page();
            refresh.Activate();
            refresh.ShowDialog();
        }
    }
}
