﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Time_Reporting_Tool
{
    public partial class Add_Event_page : Form
    {
        TextBox event_details = new TextBox();
        TextBox location_details = new TextBox();
        TextBox duration_details = new TextBox();
        TextBox event_name = new TextBox();

        Button submit_event = new Button();
        Button add_event = new Button();
        Button return_EventMenu = new Button();

        Label text_date = new Label();
        Label text_eventName = new Label();
        Label text_time1 = new Label();
        Label text_details = new Label();
        Label text_location = new Label();
        Label text_duration = new Label();

        NumericUpDown hour = new NumericUpDown();
        NumericUpDown min = new NumericUpDown();

        GroupBox box = new GroupBox();
        GroupBox box2 = new GroupBox();

        ComboBox option_combo = new ComboBox();

        DateTimePicker date_pick = new DateTimePicker();

        RadioButton option1 = new RadioButton();
        RadioButton option2 = new RadioButton();

        public Add_Event_page()
        {
            InitializeComponent();
            submit_event.Click += new EventHandler(this.submittion_Click);
            add_event.Click += new EventHandler(this.submit_contact_Click);
            return_EventMenu.Click += new EventHandler(this.return_menu1_Click);

            this.Controls.Add(add_event);
            add_event.Top = 470;
            add_event.Left = 10;
            add_event.Text = "Add Event";
            add_event.Font = new Font("Century Gothic", 14, FontStyle.Bold);
            add_event.FlatStyle = FlatStyle.Flat;
            add_event.FlatAppearance.BorderColor = Color.Silver;
            add_event.BringToFront();
            add_event.Cursor = Cursors.Hand;
            add_event.Size = new System.Drawing.Size(180, 35);

            this.Controls.Add(return_EventMenu);
            return_EventMenu.Top = 465;
            return_EventMenu.Left = 560;
            return_EventMenu.Text = "Return to Event Menu";
            return_EventMenu.Font = new Font("Century Gothic", 14, FontStyle.Bold);
            return_EventMenu.FlatStyle = FlatStyle.Flat;
            return_EventMenu.FlatAppearance.BorderColor = Color.Silver;
            return_EventMenu.BringToFront();
            return_EventMenu.Cursor = Cursors.Hand;
            return_EventMenu.Size = new System.Drawing.Size(230, 38);
        }

        private void return_menu1_Click(object sender, EventArgs e)
        {
            this.Hide();
            
            Event_Main_Menucs back2 = new Event_Main_Menucs();
            back2.Activate();
            back2.ShowDialog();
        }

        private void assets()
        {
            int i = 0;
            
            /*******************************This is for the textboxes and radiobuttons to appear***********************************/
            this.Controls.Add(box);
            box.Controls.Add(option1);
            box.Controls.Add(option2);
            box.Top = 130;
            box.Left = 40;
            box.Text = "Event Type: ";
            box.Font = new Font("Century Gothic", 11);

            this.Controls.Add(box2);
            box2.Controls.Add(option_combo);
            box2.Top = 310;
            box2.Left = 40;
            box2.Text = "Event Option: ";
            box2.Font = new Font("Century Gothic", 11);

            this.Controls.Add(option1);
            option1.Top = 165;
            option1.Left = 70;
            option1.Text = "Task";
            option1.Font = new Font("Century Gothic", 10);
            option1.BringToFront();
            option1.Size = new System.Drawing.Size(120, 25);

            this.Controls.Add(option2);
            option2.Top = 185;
            option2.Left = 70;
            option2.Text = "Appointment";
            option2.Font = new Font("Century Gothic", 10);
            option2.BringToFront();
            option2.Size = new System.Drawing.Size(120, 25);

            this.Controls.Add(submit_event);
            submit_event.Top = 470;
            submit_event.Left = 280;
            submit_event.Text = "Submit Event";
            submit_event.Font = new Font("Century Gothic", 14, FontStyle.Bold);
            submit_event.FlatStyle = FlatStyle.Flat;
            submit_event.FlatAppearance.BorderColor = Color.Silver;
            submit_event.BringToFront();
            submit_event.Cursor = Cursors.Hand;
            submit_event.Size = new System.Drawing.Size(180, 35);

            this.Controls.Add(option_combo);
            option_combo.Top = 360;
            option_combo.Left = 70;
            option_combo.Items.Add(Text = "One-Off");
            option_combo.Items.Add(Text = "Recurring");
            option_combo.BringToFront();
            option_combo.Size = new System.Drawing.Size(120, 25);

            this.Controls.Add(date_pick);
            date_pick.Top = 200;
            date_pick.Left = 360;
            date_pick.Size = new System.Drawing.Size(150, 25);

            this.Controls.Add(event_details);
            event_details.Top = 190;
            event_details.Left = 560;
            event_details.Multiline = true;
            event_details.Size = new System.Drawing.Size(200, 180);

            this.Controls.Add(location_details);
            location_details.Top = 390;
            location_details.Left = 360;
            location_details.Size = new System.Drawing.Size(150, 25);

            this.Controls.Add(hour);
            hour.Top = 260;
            hour.Left = 360;
            hour.Maximum = 23;
            hour.Size = new System.Drawing.Size(40, 25);

            this.Controls.Add(min);
            min.Top = 260;
            min.Left = 430;
            min.Maximum = 59;
            min.Size = new System.Drawing.Size(40, 25);

            this.Controls.Add(duration_details);
            duration_details.Top = 320;
            duration_details.Left = 360;
            duration_details.Size = new System.Drawing.Size(150, 25);

            this.Controls.Add(event_name);
            event_name.Top = 140;
            event_name.Left = 360;
            event_name.Size = new System.Drawing.Size(150, 25);

            /*******************************************This is for the labels to appear********************************************/
            System.Drawing.Point label1 = new System.Drawing.Point(307, 200 + i * 10);
            text_date.Location = label1;
            text_date.Text = "Date: ";
            text_date.Font = new Font("Century Gothic", 10);
            this.Controls.Add(text_date);

            System.Drawing.Point label2 = new System.Drawing.Point(310, 260 + i * 10);
            text_time1.Location = label2;
            text_time1.Text = "Time: ";
            text_time1.Font = new Font("Century Gothic", 10);
            this.Controls.Add(text_time1);

            System.Drawing.Point label3 = new System.Drawing.Point(560, 170 + i * 10);
            text_details.Location = label3;
            text_details.Text = "Event Details: ";
            text_details.Size = new System.Drawing.Size(120, 25);
            text_details.Font = new Font("Century Gothic", 10);
            this.Controls.Add(text_details);

            System.Drawing.Point label4 = new System.Drawing.Point(280, 390 + i * 10);
            text_location.Location = label4;
            text_location.Text = "Location: ";
            text_location.Size = new System.Drawing.Size(120, 25);
            text_location.Font = new Font("Century Gothic", 10);
            this.Controls.Add(text_location);

            System.Drawing.Point label5 = new System.Drawing.Point(280, 320 + i * 10);
            text_duration.Location = label5;
            text_duration.Text = "Duration: ";
            text_duration.Size = new System.Drawing.Size(120, 25);
            text_duration.Font = new Font("Century Gothic", 10);
            this.Controls.Add(text_duration);

            System.Drawing.Point label6 = new System.Drawing.Point(255, 140 + i * 10);
            text_eventName.Location = label6;
            text_eventName.Text = "Event Name: ";
            text_eventName.Size = new System.Drawing.Size(120, 25);
            text_eventName.Font = new Font("Century Gothic", 10);
            this.Controls.Add(text_eventName);

        }

        private void submit_contact_Click(object sender, EventArgs e)
        {
            assets();
        }

        private void submittion_Click(object sender, EventArgs e)
        {

            if (option1.Checked != true && option2.Checked != true)
            {
                MessageBox.Show("Please Enter Your Event!");
            } 
            else if (option_combo.Text.Equals("") || event_details.Text.Equals("") || duration_details.Text.Equals(""))
            {
                MessageBox.Show("Please Enter Your Event!");
            } 
            else
            {
                OleDbCommand command;
                OleDbConnection dbConnection = new OleDbConnection();

                dbConnection.ConnectionString = ConfigurationManager.ConnectionStrings["connection_add"].ToString();
                dbConnection.Open();

                command = new OleDbCommand("INSERT INTO [Event] (EventName, Type, OptionType, DateEvent, TimeEvent, Location, EventDetails, Duration) " +
                    "VALUES (@eventName, @type, @optionTypes, @dateEvent, @timeEvent, @location, @eventDetails, @duration)", dbConnection);

                command.Parameters.AddWithValue("@eventName", event_name.Text);

                if (option1.Checked == true)
                {
                    command.Parameters.AddWithValue("@type", "Task");
                }
                else
                {
                    command.Parameters.AddWithValue("@type", "Appointment");
                }

                command.Parameters.AddWithValue("@optionTypes", option_combo.Text);
                command.Parameters.AddWithValue("@dateEvent", date_pick.Text);
                command.Parameters.AddWithValue("@timeEvent", hour.Text + " : " + min.Text);
                command.Parameters.AddWithValue("@location", location_details.Text);
                command.Parameters.AddWithValue("@eventDetails", event_details.Text);
                command.Parameters.AddWithValue("@duration", duration_details.Text);

                command.Connection = dbConnection;

                int i = command.ExecuteNonQuery();

                if (i > 0)
                {
                    MessageBox.Show("Your Event have been Saved!");

                    event_name.Clear();
                    option1.Checked = false;
                    option2.Checked = false;
                    date_pick.Value = DateTime.Now;
                    option_combo.Text = "";
                    location_details.Clear();
                    event_details.Clear();
                    duration_details.Clear();
                }

                dbConnection.Close();
            }
        }
    }
}
