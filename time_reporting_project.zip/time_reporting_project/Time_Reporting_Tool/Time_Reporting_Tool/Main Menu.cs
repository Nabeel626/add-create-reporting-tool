﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Time_Reporting_Tool
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void enter_contact_Click(object sender, EventArgs e)
        {
            this.Hide();
            
            Contact_Main_Menu click1 = new Contact_Main_Menu();
            click1.Activate();
            click1.ShowDialog();
        }

        private void Enter_event_Click(object sender, EventArgs e)
        {
            this.Hide();

            Event_Main_Menucs event1 = new Event_Main_Menucs();
            event1.Activate();
            event1.ShowDialog();

        }

        private void produce_report_Click(object sender, EventArgs e)
        {
            this.Hide();
            
            Produce_Report_Main_Menu report1 = new Produce_Report_Main_Menu();
            report1.Activate();
            report1.Show();
        }
    }
}
