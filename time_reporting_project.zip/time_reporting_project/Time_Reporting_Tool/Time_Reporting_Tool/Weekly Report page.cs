﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Time_Reporting_Tool
{
    public partial class Weekly_Report_page : Form
    {
        Button view_weekly = new Button();
        Button return_main_menu = new Button();

        DateTimePicker date1 = new DateTimePicker();
        ListBox searchlist = new ListBox();

        Label ID = new Label();
        Label Event_Name = new Label();
        Label Date_label1 = new Label();
        Label Date_label = new Label();
        Label Time_label = new Label();
        Label Duration_label = new Label();
        Label Location_label = new Label();
        Label EventDetails_label = new Label();

        TextBox textBox_ID = new TextBox();
        TextBox textBox_eventName = new TextBox();
        TextBox textBox_Type = new TextBox();
        TextBox textBox_Option = new TextBox();
        TextBox textBox_Time = new TextBox();
        TextBox textBox_duration = new TextBox();
        TextBox textBox_location = new TextBox();
        TextBox textBox_eventDetails = new TextBox();

        GroupBox box = new GroupBox();
        GroupBox box2 = new GroupBox();

        DateTimePicker date_pick = new DateTimePicker();


        public Weekly_Report_page()
        {
            InitializeComponent();
           
        }

        private void Weekly_Report_page_Load(object sender, EventArgs e)
        {
            int i = 0;

            /*******************************This is for the textboxes and groupboxes to appear***********************************/
            this.Controls.Add(date1);
            date1.Top = 120;
            date1.Left = 490;
            date1.Size = new System.Drawing.Size(170, 25);

            this.Controls.Add(view_weekly);
            view_weekly.Top = 545;
            view_weekly.Left = 15;
            view_weekly.Text = "View Weekly";
            view_weekly.Font = new Font("Century Gothic", 14, FontStyle.Bold);
            view_weekly.FlatStyle = FlatStyle.Flat;
            view_weekly.FlatAppearance.BorderColor = Color.Silver;
            view_weekly.BringToFront();
            view_weekly.Cursor = Cursors.Hand;
            view_weekly.Size = new System.Drawing.Size(180, 35);
            view_weekly.Click += new EventHandler(this.view);

            this.Controls.Add(return_main_menu);
            return_main_menu.Top = 545;
            return_main_menu.Left = 760;
            return_main_menu.Text = "Return to Report Menu";
            return_main_menu.Font = new Font("Century Gothic", 14, FontStyle.Bold);
            return_main_menu.FlatStyle = FlatStyle.Flat;
            return_main_menu.FlatAppearance.BorderColor = Color.Silver;
            return_main_menu.Click += new EventHandler(this.return_main_menu_Click);
            return_main_menu.BringToFront();
            return_main_menu.Cursor = Cursors.Hand;
            return_main_menu.Size = new System.Drawing.Size(250, 35);
            return_main_menu.Click += new EventHandler(this.view);

            this.Controls.Add(searchlist);
            searchlist.Top = 170;
            searchlist.Left = 820;
            searchlist.Size = new Size(170, 300);
            searchlist.Click += new EventHandler(this.listsearch);

            this.Controls.Add(box);
            box.Controls.Add(textBox_Type);
            box.Top = 240;
            box.Left = 60;
            box.Text = "Event Type: ";
            box.Font = new Font("Century Gothic", 11);

            this.Controls.Add(box2);
            box2.Controls.Add(textBox_Option);
            box2.Top = 380;
            box2.Left = 60;
            box2.Text = "Event Option: ";
            box2.Font = new Font("Century Gothic", 11);

            this.Controls.Add(textBox_Type);
            textBox_Type.Top = 285;
            textBox_Type.Enabled = false;
            textBox_Type.Left = 90;
            textBox_Type.BringToFront();
            textBox_Type.Size = new System.Drawing.Size(130, 25);

            this.Controls.Add(textBox_Option);
            textBox_Option.Top = 425;
            textBox_Option.Left = 90;
            textBox_Option.Enabled = false;
            textBox_Option.BringToFront();
            textBox_Option.Size = new System.Drawing.Size(130, 25);

            this.Controls.Add(textBox_ID);
            textBox_ID.Top = 180;
            textBox_ID.Left = 130;
            textBox_ID.Enabled = false;
            textBox_ID.Size = new System.Drawing.Size(120, 25);

            this.Controls.Add(date_pick);
            date_pick.Top = 180;
            date_pick.Left = 370;
            date_pick.Enabled = false;
            date_pick.Size = new System.Drawing.Size(170, 25);

            this.Controls.Add(textBox_Time);
            textBox_Time.Top = 260;
            textBox_Time.Left = 370;
            textBox_Time.Enabled = false;
            textBox_Time.Size = new System.Drawing.Size(170, 25);

            this.Controls.Add(textBox_duration);
            textBox_duration.Top = 340;
            textBox_duration.Left = 370;
            textBox_duration.Enabled = false;
            textBox_duration.Size = new System.Drawing.Size(170, 25);

            this.Controls.Add(textBox_location);
            textBox_location.Top = 420;
            textBox_location.Multiline = true;
            textBox_location.Left = 370;
            textBox_location.Enabled = false;
            textBox_location.Size = new System.Drawing.Size(170, 40);

            this.Controls.Add(textBox_eventName);
            textBox_eventName.Top = 210;
            textBox_eventName.Left = 580;
            textBox_eventName.Enabled = false;
            textBox_eventName.Size = new System.Drawing.Size(200, 25);

            this.Controls.Add(textBox_eventDetails);
            textBox_eventDetails.Top = 290;
            textBox_eventDetails.Multiline = true;
            textBox_eventDetails.Left = 580;
            textBox_eventDetails.Enabled = false;
            textBox_eventDetails.Size = new System.Drawing.Size(200, 170);

            /************************************This is for the labels and buttons to appear*************************************/
            System.Drawing.Point label1 = new System.Drawing.Point(80, 180 + i * 10);
            ID.Location = label1;
            ID.Text = "ID: ";
            ID.Font = new Font("Century Gothic", 10);
            this.Controls.Add(ID);

            System.Drawing.Point label2 = new System.Drawing.Point(310, 180 + i * 10);
            Date_label.Location = label2;
            Date_label.Text = "Date: ";
            Date_label.Font = new Font("Century Gothic", 10);
            this.Controls.Add(Date_label);

            System.Drawing.Point label3 = new System.Drawing.Point(315, 260 + i * 10);
            Time_label.Location = label3;
            Time_label.Text = "Time: ";
            Time_label.Font = new Font("Century Gothic", 10);
            this.Controls.Add(Time_label);

            System.Drawing.Point label4 = new System.Drawing.Point(287, 340 + i * 10);
            Duration_label.Location = label4;
            Duration_label.Text = "Duration: ";
            Duration_label.Font = new Font("Century Gothic", 10);
            this.Controls.Add(Duration_label);

            System.Drawing.Point label5 = new System.Drawing.Point(287, 420 + i * 10);
            Location_label.Location = label5;
            Location_label.Text = "Location: ";
            Location_label.Font = new Font("Century Gothic", 10);
            this.Controls.Add(Location_label);

            System.Drawing.Point label6 = new System.Drawing.Point(580, 257 + i * 10);
            EventDetails_label.Location = label6;
            EventDetails_label.Text = "Event Details: ";
            EventDetails_label.Size = new System.Drawing.Size(180, 150);
            EventDetails_label.Font = new Font("Century Gothic", 10);
            this.Controls.Add(EventDetails_label);

            System.Drawing.Point label7 = new System.Drawing.Point(580, 178 + i * 10);
            Event_Name.Location = label7;
            Event_Name.Text = "Event Name: ";
            Event_Name.Size = new System.Drawing.Size(180, 150);
            Event_Name.Font = new Font("Century Gothic", 10);
            this.Controls.Add(Event_Name);

            System.Drawing.Point label8 = new System.Drawing.Point(400, 120 + i * 10);
            Date_label1.Location = label8;
            Date_label1.Text = "From Date: ";
            Date_label1.Size = new System.Drawing.Size(180, 150);
            Date_label1.Font = new Font("Century Gothic", 10);
            this.Controls.Add(Date_label1);
        }

        private void listsearch(object sender, EventArgs e)
        {
            OleDbCommand command;
            OleDbConnection dbConnection = new OleDbConnection();

            dbConnection.ConnectionString = ConfigurationManager.ConnectionStrings["connection_add"].ToString();
            dbConnection.Open();
            command = new OleDbCommand("SELECT * FROM [Event] WHERE EventName='" + searchlist.Text + "' ", dbConnection);

            command.Connection = dbConnection;
            OleDbDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                textBox_ID.Text = reader["ID"].ToString();
                textBox_eventName.Text = reader["EventName"].ToString();
                textBox_Type.Text = reader["Type"].ToString();
                textBox_Option.Text = reader["OptionType"].ToString();
                date_pick.Text = reader["DateEvent"].ToString();
                textBox_Time.Text = reader["TimeEvent"].ToString();
                textBox_duration.Text = reader["Duration"].ToString();
                textBox_location.Text = reader["Location"].ToString();
                textBox_eventDetails.Text = reader["EventDetails"].ToString();

            }

            dbConnection.Close();
        }

        private void view(object sender, EventArgs e)
        {           
            
            OleDbCommand command1;
            OleDbConnection dbConnection = new OleDbConnection();

            dbConnection.ConnectionString = ConfigurationManager.ConnectionStrings["connection_add"].ToString();
            dbConnection.Open();
            command1 = new OleDbCommand("SELECT * FROM [Event] where DateEvent between (From) and (To)");
            command1.Connection = dbConnection;

            command1.Parameters.AddWithValue("from", date1.Value.AddDays(-1));
            command1.Parameters.AddWithValue("to", date1.Value.AddDays(7));

            OleDbDataReader reader = command1.ExecuteReader();
            while (reader.Read())
            {
                searchlist.Items.Add(reader["EventName"].ToString());
            }
        }

        private void return_main_menu_Click(object sender, EventArgs e)
        {
            this.Hide();

            Produce_Report_Main_Menu return_back = new Produce_Report_Main_Menu();
            return_back.Activate();
            return_back.ShowDialog();
        }
    }       
}

