﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Time_Reporting_Tool
{
    public partial class Event_Main_Menucs : Form
    {
        public Event_Main_Menucs()
        {
            InitializeComponent();
        }

        private void Return_menu1_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form1 back = new Form1();
            back.Activate();
            back.ShowDialog();
        }

        private void View_contact_Click(object sender, EventArgs e)
        {
            this.Hide();

            View_Event_page view1 = new View_Event_page();
            view1.Activate();
            view1.ShowDialog();
        }

        private void Edit_contact_Click(object sender, EventArgs e)
        {
            this.Hide();

            Edit_Event_page edit1 = new Edit_Event_page();
            edit1.Activate();
            edit1.ShowDialog();
        }

        private void Add_contact_Click(object sender, EventArgs e)
        {
            this.Hide();

            Add_Event_page add1 = new Add_Event_page();
            add1.Activate();
            add1.ShowDialog();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
