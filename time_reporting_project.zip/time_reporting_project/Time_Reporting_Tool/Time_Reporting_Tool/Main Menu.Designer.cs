﻿namespace Time_Reporting_Tool
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.produce_report = new System.Windows.Forms.Button();
            this.enter_event = new System.Windows.Forms.Button();
            this.enter_contact = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // produce_report
            // 
            this.produce_report.Cursor = System.Windows.Forms.Cursors.Hand;
            this.produce_report.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.produce_report.Location = new System.Drawing.Point(376, 425);
            this.produce_report.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.produce_report.Name = "produce_report";
            this.produce_report.Size = new System.Drawing.Size(221, 78);
            this.produce_report.TabIndex = 3;
            this.produce_report.Text = "Produce Report";
            this.produce_report.UseVisualStyleBackColor = true;
            this.produce_report.Click += new System.EventHandler(this.produce_report_Click);
            // 
            // enter_event
            // 
            this.enter_event.Cursor = System.Windows.Forms.Cursors.Hand;
            this.enter_event.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enter_event.Location = new System.Drawing.Point(376, 298);
            this.enter_event.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.enter_event.Name = "enter_event";
            this.enter_event.Size = new System.Drawing.Size(221, 78);
            this.enter_event.TabIndex = 2;
            this.enter_event.Text = "Enter Event";
            this.enter_event.UseVisualStyleBackColor = true;
            this.enter_event.Click += new System.EventHandler(this.Enter_event_Click);
            // 
            // enter_contact
            // 
            this.enter_contact.Cursor = System.Windows.Forms.Cursors.Hand;
            this.enter_contact.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enter_contact.Location = new System.Drawing.Point(376, 173);
            this.enter_contact.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.enter_contact.Name = "enter_contact";
            this.enter_contact.Size = new System.Drawing.Size(221, 78);
            this.enter_contact.TabIndex = 1;
            this.enter_contact.Text = "Enter Contact";
            this.enter_contact.UseVisualStyleBackColor = true;
            this.enter_contact.Click += new System.EventHandler(this.enter_contact_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(-3, -1);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(941, 123);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Agency FB", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(13, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(231, 73);
            this.label1.TabIndex = 0;
            this.label1.Text = "Main Menu";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(939, 574);
            this.Controls.Add(this.produce_report);
            this.Controls.Add(this.enter_event);
            this.Controls.Add(this.enter_contact);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Menu";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button produce_report;
        private System.Windows.Forms.Button enter_event;
        private System.Windows.Forms.Button enter_contact;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
    }
}

