﻿namespace Time_Reporting_Tool
{
    partial class Add_Contact_page
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.return_menu2 = new System.Windows.Forms.Button();
            this.submit_contact = new System.Windows.Forms.Button();
            this.marking = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.save_contact = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // return_menu2
            // 
            this.return_menu2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.return_menu2.BackColor = System.Drawing.Color.Silver;
            this.return_menu2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.return_menu2.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.return_menu2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.return_menu2.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.return_menu2.Location = new System.Drawing.Point(769, 626);
            this.return_menu2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.return_menu2.Name = "return_menu2";
            this.return_menu2.Size = new System.Drawing.Size(322, 41);
            this.return_menu2.TabIndex = 6;
            this.return_menu2.Text = "Return To Contact Menu";
            this.return_menu2.UseVisualStyleBackColor = false;
            this.return_menu2.Click += new System.EventHandler(this.return_menu2_Click);
            // 
            // submit_contact
            // 
            this.submit_contact.Cursor = System.Windows.Forms.Cursors.Hand;
            this.submit_contact.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.submit_contact.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.submit_contact.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.submit_contact.Location = new System.Drawing.Point(12, 628);
            this.submit_contact.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.submit_contact.Name = "submit_contact";
            this.submit_contact.Size = new System.Drawing.Size(217, 39);
            this.submit_contact.TabIndex = 21;
            this.submit_contact.Text = "Add contact";
            this.submit_contact.UseVisualStyleBackColor = true;
            this.submit_contact.Click += new System.EventHandler(this.save_contact_Click);
            // 
            // marking
            // 
            this.marking.AutoSize = true;
            this.marking.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.marking.Location = new System.Drawing.Point(375, 143);
            this.marking.Name = "marking";
            this.marking.Size = new System.Drawing.Size(375, 23);
            this.marking.TabIndex = 22;
            this.marking.Text = "Anything marked with * is compulsory";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Agency FB", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(13, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(258, 73);
            this.label1.TabIndex = 0;
            this.label1.Text = "Add Contact";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1104, 123);
            this.panel1.TabIndex = 2;
            // 
            // save_contact
            // 
            this.save_contact.Cursor = System.Windows.Forms.Cursors.Hand;
            this.save_contact.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.save_contact.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.save_contact.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.save_contact.Location = new System.Drawing.Point(443, 628);
            this.save_contact.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.save_contact.Name = "save_contact";
            this.save_contact.Size = new System.Drawing.Size(217, 39);
            this.save_contact.TabIndex = 23;
            this.save_contact.Text = "Save contact";
            this.save_contact.UseVisualStyleBackColor = true;
            this.save_contact.Click += new System.EventHandler(this.save_contact_Click_1);
            // 
            // Add_Contact_page
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1103, 678);
            this.Controls.Add(this.save_contact);
            this.Controls.Add(this.marking);
            this.Controls.Add(this.submit_contact);
            this.Controls.Add(this.return_menu2);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Add_Contact_page";
            this.Text = "Add_Contact_page";
            this.Load += new System.EventHandler(this.Add_Contact_page_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button return_menu2;
        private System.Windows.Forms.Button submit_contact;
        private System.Windows.Forms.Label marking;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button save_contact;
    }
}