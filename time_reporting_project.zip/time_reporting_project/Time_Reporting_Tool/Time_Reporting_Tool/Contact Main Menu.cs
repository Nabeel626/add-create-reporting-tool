﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Time_Reporting_Tool
{
    public partial class Contact_Main_Menu : Form
    {
        public Contact_Main_Menu()
        {
            InitializeComponent();
        }

        private void add_contact_Click(object sender, EventArgs e)
        {
            this.Hide();

            Add_Contact_page add = new Add_Contact_page();
            add.Activate();
            add.ShowDialog();
        }

        private void return_menu1_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form1 back = new Form1();
            back.Activate();
            back.ShowDialog();
        }

        private void Edit_contact_Click(object sender, EventArgs e)
        {
            this.Hide();

            Edit_Contact_page edit = new Edit_Contact_page();
            edit.Activate();
            edit.ShowDialog();
        }

        private void View_contact_Click(object sender, EventArgs e)
        {
            this.Hide();

            View_Contact_page view = new View_Contact_page();
            view.Activate();
            view.ShowDialog();
        }
    }
}
