﻿namespace Time_Reporting_Tool
{
    partial class Produce_Report_Main_Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.four_week_report = new System.Windows.Forms.Button();
            this.return_menu1 = new System.Windows.Forms.Button();
            this.weekly_report = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(1, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1048, 123);
            this.panel1.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Agency FB", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(13, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(444, 73);
            this.label1.TabIndex = 0;
            this.label1.Text = "Produce Report Menu";
            // 
            // four_week_report
            // 
            this.four_week_report.Cursor = System.Windows.Forms.Cursors.Hand;
            this.four_week_report.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.four_week_report.Location = new System.Drawing.Point(669, 294);
            this.four_week_report.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.four_week_report.Name = "four_week_report";
            this.four_week_report.Size = new System.Drawing.Size(221, 78);
            this.four_week_report.TabIndex = 14;
            this.four_week_report.Text = "4 Week Report";
            this.four_week_report.UseVisualStyleBackColor = true;
            this.four_week_report.Click += new System.EventHandler(this.four_week_report_Click);
            // 
            // return_menu1
            // 
            this.return_menu1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.return_menu1.BackColor = System.Drawing.Color.Silver;
            this.return_menu1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.return_menu1.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.return_menu1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.return_menu1.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.return_menu1.Location = new System.Drawing.Point(785, 579);
            this.return_menu1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.return_menu1.Name = "return_menu1";
            this.return_menu1.Size = new System.Drawing.Size(251, 59);
            this.return_menu1.TabIndex = 13;
            this.return_menu1.Text = "Return To Menu";
            this.return_menu1.UseVisualStyleBackColor = false;
            this.return_menu1.Click += new System.EventHandler(this.return_menu1_Click);
            // 
            // weekly_report
            // 
            this.weekly_report.Cursor = System.Windows.Forms.Cursors.Hand;
            this.weekly_report.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weekly_report.Location = new System.Drawing.Point(163, 294);
            this.weekly_report.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.weekly_report.Name = "weekly_report";
            this.weekly_report.Size = new System.Drawing.Size(221, 78);
            this.weekly_report.TabIndex = 11;
            this.weekly_report.Text = "Weekly Report";
            this.weekly_report.UseVisualStyleBackColor = true;
            this.weekly_report.Click += new System.EventHandler(this.weekly_report_Click);
            // 
            // Produce_Report_Main_Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1048, 649);
            this.Controls.Add(this.four_week_report);
            this.Controls.Add(this.return_menu1);
            this.Controls.Add(this.weekly_report);
            this.Controls.Add(this.panel1);
            this.Name = "Produce_Report_Main_Menu";
            this.Text = "Produce_Report_Main_Menu";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button four_week_report;
        private System.Windows.Forms.Button return_menu1;
        private System.Windows.Forms.Button weekly_report;
    }
}